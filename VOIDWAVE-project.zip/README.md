# VOIDWAVE

Run `npm install`, then `npm run dev`. The API listens on port 8787 and Vite on port 5173.

The local development API persists data in `server/data.json` and media in `server/uploads/` (both ignored by git). It is intentionally a development adapter; production deployment should use Firebase Auth, Firestore, and Storage using the environment configuration in `.env.example`. Google sign-in only activates when a real provider is configured, rather than presenting a fake sign-in flow.
