export type User={id:string;email:string;username:string;displayName:string;bio:string;avatar?:string;followers:number;following:number};
export type Track={id:string;ownerId:string;title:string;artist:string;description:string;genre:string;tags:string[];audioUrl:string;coverUrl?:string;createdAt:string;plays:number;likes:string[];liked?:boolean;commentCount?:number;owner:User};
export type Playlist={id:string;ownerId:string;name:string;description:string;visibility:string;trackIds:string[];tracks?:Track[]};
